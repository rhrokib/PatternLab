#!/usr/bin/env python
# _*_ coding: utf-8 _*_

__all__ = [
    'KNN',
    'LR',
    'MLP',
    'RF',
    'SVM',
]