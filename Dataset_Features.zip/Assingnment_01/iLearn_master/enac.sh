#bin/bash

files=( "NA_train_sp" "NA_test_sp" "PA_train_sp" "PA_test_sp")


for i in "${files[@]}"
do
    for ((j=5; j+=5; j<=10))
    do
        python descnucleotide/ENAC.py --file content/drive/My Drive/prLab/dataset/$i.txt --slwindow &j --format csv --out content/drive/My Drive/prLab/features/ENAC/$i $j.csv
done